const Colors = {
    primary : "#090040",
    secondary : "#fbaf03",
    dark_grey : "#343A40",
    grey : "grey",
    medium_grey : "#bdc3c7",
    // light_grey : "#F5EFEF",
    light_grey : "#f6f6f8",
    blue : "#3db5c6",
    fb : "#3b5998",
    google : "#ea4335"
}

export default Colors;